# VeyraCalc - Native Android Scientific Calculator

VeyraCalc is a modern, lightweight, and offline scientific calculator app built in **Kotlin** and **Jetpack Compose** using Material 3 design principles.

## Features
- **Arithmetic & Scientific Math**: `sin`, `cos`, `tan`, `log`, `ln`, `√`, `^`, `!`, `π`, `e`, and nested parentheses.
- **Angle Modes**: DEG (Degrees) and RAD (Radians) modes.
- **Offline History**: Persisted locally via SharedPreferences without remote databases.
- **Formula Library**: Offline searchable cheat-sheet for Algebra, Geometry, Trigonometry, Calculus, and Physics.
- **Unit Converter**: Real-time conversion across length, weight, temperature, speed, and digital data.
- **Percentage Calculator**: Quick tools for % of, % change, and tipping.
- **Light & Dark Themes**: Deep navy blue, electric cyan, and crisp white styling.
- **Production-Ready Gradle Configuration**: Prepares reserved AdMob banner area and Google Play Billing hooks.

## How to Build the APK

### Method 1: Android Studio (Recommended)
1. Extract the downloaded `VeyraCalc-Android-Project.zip` to a folder on your computer.
2. Open **Android Studio** (Koala / Ladybug or newer with JDK 17+).
3. Select **Open an Existing Project** and choose the extracted folder.
4. Let Gradle sync dependencies automatically.
5. To test in an emulator or connected phone, click the green **Run** button (or `Shift + F10`).
6. To generate an installable APK:
   - Go to menu: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   - Once completed, Android Studio displays a notification with a **locate** link to `app/build/outputs/apk/debug/app-debug.apk`.

### Method 2: Command Line (Gradle)
Run the following inside the project root directory:

```bash
# Build debug APK
./gradlew assembleDebug

# Output APK location:
# app/build/outputs/apk/debug/app-debug.apk

# Build release APK (signed):
./gradlew assembleRelease

# Run unit tests:
./gradlew test
```
