package com.veyra.calc

import com.veyra.calc.engine.AngleMode
import com.veyra.calc.engine.CalculatorEngine
import org.junit.Assert.*
import org.junit.Test

class CalculatorEngineTest {

    @Test
    fun testBasicArithmeticAndPrecedence() {
        val res1 = CalculatorEngine.evaluate("15 + 27 - 12")
        assertTrue(res1.success)
        assertEquals("30", res1.result)

        val res2 = CalculatorEngine.evaluate("12 + 8 * 5")
        assertTrue(res2.success)
        assertEquals("52", res2.result)

        val res3 = CalculatorEngine.evaluate("(12 + 8) * 5")
        assertTrue(res3.success)
        assertEquals("100", res3.result)
    }

    @Test
    fun testDivisionByZeroSafety() {
        val res = CalculatorEngine.evaluate("42 / 0")
        assertFalse(res.success)
        assertTrue(res.error?.contains("Cannot divide by zero", ignoreCase = true) == true)
    }

    @Test
    fun testTrigonometryDegrees() {
        val sin30 = CalculatorEngine.evaluate("sin(30)", AngleMode.DEG)
        assertTrue(sin30.success)
        assertEquals(0.5, sin30.numericValue!!, 1e-6)

        val cos60 = CalculatorEngine.evaluate("cos(60)", AngleMode.DEG)
        assertTrue(cos60.success)
        assertEquals(0.5, cos60.numericValue!!, 1e-6)

        val tan45 = CalculatorEngine.evaluate("tan(45)", AngleMode.DEG)
        assertTrue(tan45.success)
        assertEquals(1.0, tan45.numericValue!!, 1e-6)

        val cos90 = CalculatorEngine.evaluate("cos(90)", AngleMode.DEG)
        assertTrue(cos90.success)
        assertEquals(0.0, cos90.numericValue!!, 1e-6)
    }

    @Test
    fun testTrigonometryRadians() {
        val sinHalfPi = CalculatorEngine.evaluate("sin(π / 2)", AngleMode.RAD)
        assertTrue(sinHalfPi.success)
        assertEquals(1.0, sinHalfPi.numericValue!!, 1e-6)
    }

    @Test
    fun testFactorial() {
        val f0 = CalculatorEngine.evaluate("0!")
        assertTrue(f0.success)
        assertEquals("1", f0.result)

        val f5 = CalculatorEngine.evaluate("5!")
        assertTrue(f5.success)
        assertEquals("120", f5.result)
    }

    @Test
    fun testPowersAndRoots() {
        val p = CalculatorEngine.evaluate("2 ^ 8")
        assertTrue(p.success)
        assertEquals("256", p.result)

        val sqrt144 = CalculatorEngine.evaluate("sqrt(144)")
        assertTrue(sqrt144.success)
        assertEquals("12", sqrt144.result)

        val negSqrt = CalculatorEngine.evaluate("sqrt(-4)")
        assertFalse(negSqrt.success)
    }

    @Test
    fun testUserAcceptanceOperations() {
        val div = CalculatorEngine.evaluate("8 ÷ 2")
        assertTrue(div.success)
        assertEquals("4", div.result)

        val add = CalculatorEngine.evaluate("7 + 5")
        assertTrue(add.success)
        assertEquals("12", add.result)

        val mul = CalculatorEngine.evaluate("6 × 7")
        assertTrue(mul.success)
        assertEquals("42", mul.result)

        val factSub = CalculatorEngine.evaluate("5! - 3")
        assertTrue(factSub.success)
        assertEquals("117", factSub.result)

        val piConst = CalculatorEngine.evaluate("2 * π")
        assertTrue(piConst.success)
        assertEquals(2 * Math.PI, piConst.numericValue!!, 1e-6)
    }
}

