package com.veyra.calc.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.veyra.calc.ui.theme.*

data class FormulaItem(val category: String, val title: String, val formula: String, val desc: String)

@Composable
fun FormulaLibraryScreen() {
    var search by remember { mutableStateOf("") }

    val allFormulas = remember {
        listOf(
            FormulaItem("Algebra", "Quadratic Formula", "x = (-b ± √(b² - 4ac)) / (2a)", "Roots of ax² + bx + c = 0"),
            FormulaItem("Algebra", "Difference of Squares", "a² - b² = (a - b)(a + b)", "Factoring binomial identity"),
            FormulaItem("Geometry", "Pythagorean Theorem", "c = √(a² + b²)", "Hypotenuse of right triangle"),
            FormulaItem("Geometry", "Circle Area", "A = π · r²", "Area enclosed by circle of radius r"),
            FormulaItem("Geometry", "Sphere Volume", "V = (4/3) · π · r³", "Total 3D volume of a sphere"),
            FormulaItem("Trigonometry", "Pythagorean Trig Identity", "sin²(θ) + cos²(θ) = 1", "Fundamental trigonometric invariant"),
            FormulaItem("Physics", "Kinetic Energy", "E = (1/2) · m · v²", "Energy of body in motion"),
            FormulaItem("Physics", "Mass-Energy Equivalence", "E = m · c²", "Einstein's relativistic energy formula"),
            FormulaItem("Calculus", "Power Rule Derivative", "d/dx [xⁿ] = n · xⁿ⁻¹", "Basic polynomial differentiation rule")
        )
    }

    val filtered = allFormulas.filter {
        it.title.contains(search, ignoreCase = true) || it.category.contains(search, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Formula Library", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)

        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            label = { Text("Search formulas...") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Navy800)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(item.category.uppercase(), fontSize = 11.sp, color = CyanAccent, fontWeight = FontWeight.SemiBold)
                        Text(item.title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(item.formula, fontSize = 16.sp, fontFamily = FontFamily.Monospace, color = CyanBright)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(item.desc, fontSize = 13.sp, color = TextSecondaryDark)
                    }
                }
            }
        }
    }
}
