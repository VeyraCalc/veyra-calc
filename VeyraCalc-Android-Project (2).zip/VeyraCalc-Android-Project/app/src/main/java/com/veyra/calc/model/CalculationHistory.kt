package com.veyra.calc.model

data class CalculationHistory(
    val id: String = java.util.UUID.randomUUID().toString(),
    val expression: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis(),
    val angleMode: String = "DEG"
)
