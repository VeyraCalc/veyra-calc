package com.veyra.calc.ui.theme

import androidx.compose.ui.graphics.Color

val Navy950 = Color(0xFF070B19)
val Navy900 = Color(0xFF0A1128)
val Navy800 = Color(0xFF001F54)
val Navy700 = Color(0xFF034078)
val Navy600 = Color(0xFF1282A2)

val CyanAccent = Color(0xFF00F2FE)
val CyanBright = Color(0xFF4FACFE)
val CyanGlow = Color(0xFF70F0FF)

val TextPrimaryDark = Color(0xFFFFFFFF)
val TextSecondaryDark = Color(0xFF8EA8C3)
val TextMutedDark = Color(0xFF5B7086)

// Light Theme Equivalents
val SurfaceLight = Color(0xFFF4F7FC)
val CardLight = Color(0xFFFFFFFF)
val TextPrimaryLight = Color(0xFF0A1128)
val TextSecondaryLight = Color(0xFF4A5568)
val CyanLightMode = Color(0xFF0284C7)
