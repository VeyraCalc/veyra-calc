package com.veyra.calc.engine

import kotlin.math.*

enum class AngleMode {
    DEG, RAD
}

data class EvalResult(
    val success: Boolean,
    val result: String? = null,
    val numericValue: Double? = null,
    val error: String? = null
)

/**
 * Pure Kotlin mathematical expression parser and evaluator.
 * Uses lexical analysis, implicit multiplication resolution,
 * and Dijkstra's Shunting-yard algorithm with an RPN evaluator.
 */
object CalculatorEngine {

    private val OPERATORS = mapOf(
        "+" to (1 to false),
        "-" to (1 to false),
        "*" to (2 to false),
        "/" to (2 to false),
        "%" to (2 to false),
        "^" to (3 to true),
        "NEG" to (4 to true),
        "!" to (5 to false)
    )

    private val KNOWN_FUNCTIONS = setOf(
        "sin", "cos", "tan",
        "asin", "acos", "atan",
        "log", "ln",
        "sqrt", "cbrt", "abs", "exp"
    )

    fun factorial(n: Double): Double {
        if (!n.isFinite()) throw ArithmeticException("Overflow")
        if (n < 0) throw ArithmeticException("Factorial requires non-negative value")
        if (floor(n) != n) throw ArithmeticException("Factorial requires whole number")
        if (n > 170) throw ArithmeticException("Result exceeds maximum limit")
        if (n == 0.0 || n == 1.0) return 1.0
        var res = 1.0
        for (i in 2..n.toInt()) {
            res *= i.toDouble()
        }
        return res
    }

    fun evaluate(rawExpr: String, angleMode: AngleMode = AngleMode.DEG): EvalResult {
        val trimmed = rawExpr.trim()
        if (trimmed.isEmpty()) {
            return EvalResult(false, error = "Empty expression")
        }

        return try {
            val tokens = tokenize(trimmed)
            val rpn = toRPN(tokens)
            val value = evaluateRPN(rpn, angleMode)
            val formatted = formatResult(value)
            EvalResult(true, result = formatted, numericValue = value)
        } catch (e: Exception) {
            EvalResult(false, error = e.message ?: "Calculation error")
        }
    }

    private data class Token(val type: TokenType, val value: String)
    private enum class TokenType { NUMBER, OPERATOR, FUNCTION, LPAREN, RPAREN }

    private fun tokenize(raw: String): List<Token> {
        val expr = raw
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")

        val tokens = mutableListOf<Token>()
        var i = 0

        while (i < expr.length) {
            val c = expr[i]
            if (c.isWhitespace()) {
                i++
                continue
            }
            if (c == 'π') {
                tokens.add(Token(TokenType.NUMBER, Math.PI.toString()))
                i++
                continue
            }
            if (c.isDigit() || (c == '.' && i + 1 < expr.length && expr[i + 1].isDigit())) {
                var num = ""
                var hasDot = false
                while (i < expr.length && (expr[i].isDigit() || expr[i] == '.')) {
                    if (expr[i] == '.') {
                        if (hasDot) throw IllegalArgumentException("Multiple decimal points")
                        hasDot = true
                    }
                    num += expr[i]
                    i++
                }
                tokens.add(Token(TokenType.NUMBER, num))
                continue
            }
            if (c.isLetter()) {
                var ident = ""
                while (i < expr.length && expr[i].isLetter()) {
                    ident += expr[i].lowercaseChar()
                    i++
                }
                if (ident == "pi") {
                    tokens.add(Token(TokenType.NUMBER, Math.PI.toString()))
                } else if (ident == "e") {
                    tokens.add(Token(TokenType.NUMBER, Math.E.toString()))
                } else if (KNOWN_FUNCTIONS.contains(ident)) {
                    tokens.add(Token(TokenType.FUNCTION, ident))
                } else {
                    throw IllegalArgumentException("Unknown function: $ident")
                }
                continue
            }
            if (c == '(') {
                tokens.add(Token(TokenType.LPAREN, "("))
                i++
                continue
            }
            if (c == ')') {
                tokens.add(Token(TokenType.RPAREN, ")"))
                i++
                continue
            }
            if (c == '!') {
                tokens.add(Token(TokenType.OPERATOR, "!"))
                i++
                continue
            }
            if (c in charArrayOf('+', '-', '*', '/', '^', '%')) {
                if (c == '-') {
                    val prev = tokens.lastOrNull()
                    if (prev == null || (prev.type == TokenType.OPERATOR && prev.value != "!") || prev.type == TokenType.LPAREN) {
                        tokens.add(Token(TokenType.OPERATOR, "NEG"))
                        i++
                        continue
                    }
                }
                tokens.add(Token(TokenType.OPERATOR, c.toString()))
                i++
                continue
            }
            throw IllegalArgumentException("Unexpected character: $c")
        }

        // Add implicit multiplication
        val withImplicit = mutableListOf<Token>()
        for (j in tokens.indices) {
            val curr = tokens[j]
            withImplicit.add(curr)
            if (j + 1 < tokens.size) {
                val next = tokens[j + 1]
                val isCurrVal = curr.type == TokenType.NUMBER || curr.type == TokenType.RPAREN || curr.value == "!"
                val isNextStart = next.type == TokenType.NUMBER || next.type == TokenType.FUNCTION || next.type == TokenType.LPAREN
                if (isCurrVal && isNextStart) {
                    withImplicit.add(Token(TokenType.OPERATOR, "*"))
                }
            }
        }
        return withImplicit
    }

    private fun toRPN(tokens: List<Token>): List<Token> {
        val out = mutableListOf<Token>()
        val stack = mutableListOf<Token>()

        for (token in tokens) {
            when (token.type) {
                TokenType.NUMBER -> out.add(token)
                TokenType.FUNCTION -> stack.add(token)
                TokenType.OPERATOR -> {
                    val (p1, rightAssoc) = OPERATORS[token.value] ?: (0 to false)
                    while (stack.isNotEmpty()) {
                        val top = stack.last()
                        if (top.type == TokenType.FUNCTION) {
                            out.add(stack.removeAt(stack.size - 1))
                            continue
                        }
                        if (top.type == TokenType.OPERATOR) {
                            val (p2, _) = OPERATORS[top.value] ?: (0 to false)
                            val shouldPop = if (rightAssoc) p1 < p2 else p1 <= p2
                            if (shouldPop) {
                                out.add(stack.removeAt(stack.size - 1))
                            } else {
                                break
                            }
                        } else {
                            break
                        }
                    }
                    stack.add(token)
                }
                TokenType.LPAREN -> stack.add(token)
                TokenType.RPAREN -> {
                    var found = false
                    while (stack.isNotEmpty()) {
                        val top = stack.removeAt(stack.size - 1)
                        if (top.type == TokenType.LPAREN) {
                            found = true
                            break
                        } else {
                            out.add(top)
                        }
                    }
                    if (!found) throw IllegalArgumentException("Mismatched parentheses")
                    if (stack.isNotEmpty() && stack.last().type == TokenType.FUNCTION) {
                        out.add(stack.removeAt(stack.size - 1))
                    }
                }
            }
        }
        while (stack.isNotEmpty()) {
            val top = stack.removeAt(stack.size - 1)
            if (top.type == TokenType.LPAREN || top.type == TokenType.RPAREN) {
                throw IllegalArgumentException("Mismatched parentheses")
            }
            out.add(top)
        }
        return out
    }

    private fun evaluateRPN(rpn: List<Token>, angleMode: AngleMode): Double {
        val stack = mutableListOf<Double>()

        for (token in rpn) {
            when (token.type) {
                TokenType.NUMBER -> {
                    stack.add(token.value.toDouble())
                }
                TokenType.OPERATOR -> {
                    if (token.value == "NEG") {
                        if (stack.isEmpty()) throw IllegalArgumentException("Syntax error")
                        val a = stack.removeAt(stack.size - 1)
                        stack.add(-a)
                    } else if (token.value == "!") {
                        if (stack.isEmpty()) throw IllegalArgumentException("Syntax error")
                        val a = stack.removeAt(stack.size - 1)
                        stack.add(factorial(a))
                    } else {
                        if (stack.size < 2) throw IllegalArgumentException("Syntax error")
                        val b = stack.removeAt(stack.size - 1)
                        val a = stack.removeAt(stack.size - 1)
                        when (token.value) {
                            "+" -> stack.add(a + b)
                            "-" -> stack.add(a - b)
                            "*" -> stack.add(a * b)
                            "/" -> {
                                if (b == 0.0) throw ArithmeticException("Cannot divide by zero")
                                stack.add(a / b)
                            }
                            "%" -> stack.add(a % b)
                            "^" -> {
                                if (a < 0 && floor(b) != b) throw ArithmeticException("Domain error: complex root")
                                stack.add(a.pow(b))
                            }
                            else -> throw IllegalArgumentException("Unsupported operator: ${token.value}")
                        }
                    }
                }
                TokenType.FUNCTION -> {
                    if (stack.isEmpty()) throw IllegalArgumentException("Missing argument for ${token.value}")
                    val arg = stack.removeAt(stack.size - 1)
                    val toRad = { deg: Double -> (deg * Math.PI) / 180.0 }
                    val fromRad = { rad: Double -> (rad * 180.0) / Math.PI }

                    when (token.value) {
                        "sin" -> {
                            val theta = if (angleMode == AngleMode.DEG) toRad(arg) else arg
                            if (angleMode == AngleMode.DEG && arg % 180.0 == 0.0) stack.add(0.0) else stack.add(sin(theta))
                        }
                        "cos" -> {
                            val theta = if (angleMode == AngleMode.DEG) toRad(arg) else arg
                            if (angleMode == AngleMode.DEG && (arg - 90.0) % 180.0 == 0.0) stack.add(0.0) else stack.add(cos(theta))
                        }
                        "tan" -> {
                            if (angleMode == AngleMode.DEG) {
                                val norm = ((arg % 180.0) + 180.0) % 180.0
                                if (abs(norm - 90.0) < 1e-9) throw ArithmeticException("Tangent undefined at 90°")
                                stack.add(tan(toRad(arg)))
                            } else {
                                stack.add(tan(arg))
                            }
                        }
                        "asin" -> {
                            if (arg < -1.0 || arg > 1.0) throw ArithmeticException("Domain error: asin in [-1, 1]")
                            val r = asin(arg)
                            stack.add(if (angleMode == AngleMode.DEG) fromRad(r) else r)
                        }
                        "acos" -> {
                            if (arg < -1.0 || arg > 1.0) throw ArithmeticException("Domain error: acos in [-1, 1]")
                            val r = acos(arg)
                            stack.add(if (angleMode == AngleMode.DEG) fromRad(r) else r)
                        }
                        "atan" -> {
                            val r = atan(arg)
                            stack.add(if (angleMode == AngleMode.DEG) fromRad(r) else r)
                        }
                        "log" -> {
                            if (arg <= 0.0) throw ArithmeticException("Domain error: log(x) requires x > 0")
                            stack.add(log10(arg))
                        }
                        "ln" -> {
                            if (arg <= 0.0) throw ArithmeticException("Domain error: ln(x) requires x > 0")
                            stack.add(ln(arg))
                        }
                        "sqrt" -> {
                            if (arg < 0.0) throw ArithmeticException("Domain error: √ requires positive number")
                            stack.add(sqrt(arg))
                        }
                        "cbrt" -> stack.add(cbrt(arg))
                        "abs" -> stack.add(abs(arg))
                        "exp" -> stack.add(exp(arg))
                        else -> throw IllegalArgumentException("Unknown function ${token.value}")
                    }
                }
                else -> {}
            }
        }
        if (stack.size != 1) throw IllegalArgumentException("Malformed syntax")
        return stack.first()
    }

    private fun formatResult(value: Double): String {
        if (!value.isFinite()) return if (value > 0) "Infinity" else "-Infinity"
        if (abs(value) < 1e-12 && value != 0.0) return "0"
        val raw = value.toString()
        if (raw.endsWith(".0")) return raw.substringBefore(".0")
        return String.format(java.util.Locale.US, "%.10g", value)
    }
}
