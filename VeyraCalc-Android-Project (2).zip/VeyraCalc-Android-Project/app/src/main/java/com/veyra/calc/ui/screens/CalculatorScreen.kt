package com.veyra.calc.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.veyra.calc.engine.AngleMode
import com.veyra.calc.engine.CalculatorEngine
import com.veyra.calc.ui.theme.*

@Composable
fun CalculatorScreen() {
    var expression by remember { mutableStateOf("") }
    var resultText by remember { mutableStateOf("") }
    var angleMode by remember { mutableStateOf(AngleMode.DEG) }
    var isScientificOpen by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // Top status row: Angle mode switcher & scientific toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledTonalButton(
                onClick = {
                    angleMode = if (angleMode == AngleMode.DEG) AngleMode.RAD else AngleMode.DEG
                },
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = if (angleMode == AngleMode.DEG) "DEG" else "RAD",
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent
                )
            }

            TextButton(onClick = { isScientificOpen = !isScientificOpen }) {
                Text(
                    text = if (isScientificOpen) "Hide Scientific" else "Show Scientific",
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Display LCD Screen
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(containerColor = Navy800),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (expression.isEmpty()) "0" else expression,
                    color = TextSecondaryDark,
                    fontSize = 24.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = if (resultText.isEmpty()) "" else "= $resultText",
                    color = CyanAccent,
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Keypad Grid
        Column(modifier = Modifier.fillMaxWidth()) {
            if (isScientificOpen) {
                ScientificRow(
                    labels = listOf("sin", "cos", "tan", "log", "ln"),
                    onKey = { key -> expression += "$key(" }
                )
                Spacer(modifier = Modifier.height(6.dp))
                ScientificRow(
                    labels = listOf("√", "^", "!", "π", "e"),
                    onKey = { key ->
                        when (key) {
                            "√" -> expression += "sqrt("
                            "^" -> expression += "^"
                            "!" -> expression += "!"
                            "π" -> expression += "π"
                            "e" -> expression += "e"
                        }
                    }
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            // Standard calculator rows
            StandardRow(listOf("C", "(", ")", "÷")) { k ->
                when (k) {
                    "C" -> { expression = ""; resultText = "" }
                    "÷" -> expression += "÷"
                    else -> expression += k
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            StandardRow(listOf("7", "8", "9", "×")) { k ->
                expression += if (k == "×") "×" else k
            }
            Spacer(modifier = Modifier.height(6.dp))
            StandardRow(listOf("4", "5", "6", "-")) { k ->
                expression += if (k == "-") "−" else k
            }
            Spacer(modifier = Modifier.height(6.dp))
            StandardRow(listOf("1", "2", "3", "+")) { k ->
                expression += k
            }
            Spacer(modifier = Modifier.height(6.dp))
            StandardRow(listOf("0", ".", "DEL", "=")) { k ->
                when (k) {
                    "DEL" -> if (expression.isNotEmpty()) expression = expression.dropLast(1)
                    "=" -> {
                        val eval = CalculatorEngine.evaluate(expression, angleMode)
                        resultText = if (eval.success) eval.result ?: "" else eval.error ?: "Error"
                    }
                    else -> expression += k
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Reserved AdMob Banner Area (Non-invasive bottom placement)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .background(Navy950, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "AdMob Banner Reserved Space (320x50)",
                color = TextMutedDark,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun ScientificRow(labels: List<String>, onKey: (String) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        labels.forEach { label ->
            Button(
                onClick = { onKey(label) },
                modifier = Modifier.weight(1f).height(44.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Navy700)
            ) {
                Text(text = label, color = CyanAccent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun StandardRow(labels: List<String>, onKey: (String) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        labels.forEach { label ->
            val isAction = label in listOf("÷", "×", "-", "+", "=")
            val isClear = label in listOf("C", "DEL")
            val containerColor = when {
                label == "=" -> CyanAccent
                isAction -> Navy600
                isClear -> Color(0xFF334155)
                else -> Navy800
            }
            val textColor = when (label) {
                "=" -> Navy950
                else -> Color.White
            }

            Button(
                onClick = { onKey(label) },
                modifier = Modifier.weight(1f).height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = containerColor)
            ) {
                Text(text = label, color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
