package com.veyra.calc.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.veyra.calc.model.CalculationHistory
import com.veyra.calc.repository.HistoryRepository
import com.veyra.calc.ui.theme.*

@Composable
fun HistoryScreen() {
    val context = LocalContext.current
    val repo = remember { HistoryRepository(context) }
    var historyList by remember { mutableStateOf(repo.getHistory()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Calculation History", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            if (historyList.isNotEmpty()) {
                TextButton(onClick = {
                    repo.clearHistory()
                    historyList = emptyList()
                }) {
                    Text("Clear", color = Color(0xFFFF5252))
                }
            }
        }

        if (historyList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text("No calculation history yet.", color = TextSecondaryDark)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(historyList) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Navy800)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(item.expression, color = TextSecondaryDark, fontSize = 15.sp, fontFamily = FontFamily.Monospace)
                            Text("= ${item.result}", color = CyanAccent, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}
