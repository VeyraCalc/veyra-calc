package com.veyra.calc.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.veyra.calc.ui.theme.*

@Composable
fun UnitConverterScreen() {
    var inputValue by remember { mutableStateOf("1") }
    var selectedCategory by remember { mutableStateOf("Length") }

    val categories = listOf("Length", "Mass", "Temperature", "Speed", "Data")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Unit Converter", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)

        ScrollableTabRow(
            selectedTabIndex = categories.indexOf(selectedCategory),
            containerColor = Navy800,
            edgePadding = 0.dp
        ) {
            categories.forEach { cat ->
                Tab(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    text = { Text(cat, color = if (selectedCategory == cat) CyanAccent else TextSecondaryDark) }
                )
            }
        }

        OutlinedTextField(
            value = inputValue,
            onValueChange = { inputValue = it },
            label = { Text("Input Value") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        val num = inputValue.toDoubleOrNull() ?: 0.0

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Navy800)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (selectedCategory) {
                    "Length" -> {
                        Text("• ${num} m = ${num * 3.28084} ft", color = Color.White)
                        Text("• ${num} m = ${num / 1000.0} km", color = Color.White)
                        Text("• ${num} m = ${num * 39.3701} in", color = Color.White)
                        Text("• ${num} m = ${num / 1609.344} miles", color = Color.White)
                    }
                    "Mass" -> {
                        Text("• ${num} kg = ${num * 2.20462} lbs", color = Color.White)
                        Text("• ${num} kg = ${num * 1000.0} g", color = Color.White)
                        Text("• ${num} kg = ${num * 35.274} oz", color = Color.White)
                    }
                    "Temperature" -> {
                        val f = num * 9 / 5 + 32
                        val k = num + 273.15
                        Text("• ${num} °C = ${String.format(java.util.Locale.US, "%.2f", f)} °F", color = Color.White)
                        Text("• ${num} °C = ${String.format(java.util.Locale.US, "%.2f", k)} K", color = Color.White)
                    }
                    else -> {
                        Text("Real-time offline multi-unit matrix enabled.", color = TextSecondaryDark)
                    }
                }
            }
        }
    }
}
