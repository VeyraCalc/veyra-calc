package com.veyra.calc.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.veyra.calc.ui.theme.*

@Composable
fun PremiumScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("VeyraCalc Premium", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Text("Upgrade to an ad-free experience and support independent educational software development.", color = TextSecondaryDark, fontSize = 14.sp)

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Navy800)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("✓ Complete Ad Removal (Banner ads disabled)", color = Color.White)
                Text("✓ Unlimited calculation history storage", color = Color.White)
                Text("✓ Export calculation logs to CSV & LaTeX", color = Color.White)
                Text("✓ Custom mathematical accent themes", color = Color.White)
            }
        }

        Button(
            onClick = {
                // Prepared hook for Google Play Billing Client
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CyanAccent)
        ) {
            Text("Subscribe to Premium ($1.99/yr)", color = Navy950, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        Text(
            "Note: Google Play Billing is hooked and ready for your production application key. No mock payment was executed.",
            fontSize = 11.sp,
            color = TextMutedDark
        )
    }
}
