package com.veyra.calc.repository

import android.content.Context
import android.content.SharedPreferences
import com.veyra.calc.model.CalculationHistory

class HistoryRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("veyra_history_prefs", Context.MODE_PRIVATE)

    fun saveCalculation(expression: String, result: String, angleMode: String) {
        val history = getHistory().toMutableList()
        val item = CalculationHistory(
            expression = expression,
            result = result,
            angleMode = angleMode
        )
        history.add(0, item) // Add newest to front
        if (history.size > 100) {
            history.removeAt(history.lastIndex)
        }
        persist(history)
    }

    fun getHistory(): List<CalculationHistory> {
        val raw = prefs.getString("history_items", null) ?: return emptyList()
        return raw.split("###").mapNotNull { entry ->
            val parts = entry.split("|||")
            if (parts.size >= 4) {
                CalculationHistory(
                    id = parts[0],
                    expression = parts[1],
                    result = parts[2],
                    timestamp = parts[3].toLongOrNull() ?: 0L,
                    angleMode = parts.getOrNull(4) ?: "DEG"
                )
            } else null
        }
    }

    fun clearHistory() {
        prefs.edit().remove("history_items").apply()
    }

    private fun persist(items: List<CalculationHistory>) {
        val serialized = items.joinToString("###") {
            "${it.id}|||${it.expression}|||${it.result}|||${it.timestamp}|||${it.angleMode}"
        }
        prefs.edit().putString("history_items", serialized).apply()
    }
}
