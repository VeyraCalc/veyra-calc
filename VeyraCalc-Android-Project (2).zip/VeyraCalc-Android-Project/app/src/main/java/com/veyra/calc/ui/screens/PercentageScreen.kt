package com.veyra.calc.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.veyra.calc.ui.theme.*

@Composable
fun PercentageScreen() {
    var valA by remember { mutableStateOf("15") }
    var valB by remember { mutableStateOf("250") }

    val numA = valA.toDoubleOrNull() ?: 0.0
    val numB = valB.toDoubleOrNull() ?: 0.0

    val percentOf = (numA / 100.0) * numB
    val whatPercent = if (numB != 0.0) (numA / numB) * 100.0 else 0.0
    val percentChange = if (numA != 0.0) ((numB - numA) / numA) * 100.0 else 0.0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Percentage Calculator", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = valA,
                onValueChange = { valA = it },
                label = { Text("Value X") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            OutlinedTextField(
                value = valB,
                onValueChange = { valB = it },
                label = { Text("Value Y") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
        }

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Navy800)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("What is X% of Y?", color = TextSecondaryDark, fontSize = 14.sp)
                Text("${valA}% of ${valB} = ${String.format(java.util.Locale.US, "%.2f", percentOf)}", color = CyanAccent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Navy800)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("X is what percentage of Y?", color = TextSecondaryDark, fontSize = 14.sp)
                Text("${valA} is ${String.format(java.util.Locale.US, "%.2f", whatPercent)}% of ${valB}", color = CyanAccent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Navy800)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Percentage Change from X to Y", color = TextSecondaryDark, fontSize = 14.sp)
                val sign = if (percentChange >= 0) "+" else ""
                Text("${sign}${String.format(java.util.Locale.US, "%.2f", percentChange)}%", color = CyanAccent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Card 4: Tip & Group Bill Split
        var billAmount by remember { mutableStateOf("68.50") }
        var tipPercent by remember { mutableStateOf("18") }
        var peopleInput by remember { mutableStateOf("2") }

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Navy800)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Tip & Group Bill Split", color = CyanAccent, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = billAmount,
                        onValueChange = { billAmount = it },
                        label = { Text("Bill ($)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = tipPercent,
                        onValueChange = { tipPercent = it },
                        label = { Text("Tip %") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = peopleInput,
                        onValueChange = { peopleInput = it },
                        label = { Text("People") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                val billNum = billAmount.toDoubleOrNull() ?: 0.0
                val tipNum = tipPercent.toDoubleOrNull() ?: 0.0
                val peopleNum = peopleInput.trim().toIntOrNull()
                val isPeopleValid = peopleNum != null && peopleNum >= 1
                val totalWithTip = billNum * (1.0 + tipNum / 100.0)

                if (!isPeopleValid) {
                    Text(
                        if (peopleInput.isBlank()) "⚠️ Enter number of people (min 1)" else "⚠️ Must be whole number >= 1",
                        color = Color(0xFFFFB74D),
                        fontSize = 12.sp
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total with Tip: $${String.format(java.util.Locale.US, "%.2f", totalWithTip)}", color = TextSecondaryDark, fontSize = 13.sp)
                    val perPersonStr = if (isPeopleValid) "$${String.format(java.util.Locale.US, "%.2f", totalWithTip / peopleNum!!)}" else "Enter people"
                    Text("Each: $perPersonStr", color = CyanAccent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
