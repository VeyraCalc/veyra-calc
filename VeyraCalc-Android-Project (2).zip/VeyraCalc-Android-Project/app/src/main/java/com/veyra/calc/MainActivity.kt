package com.veyra.calc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.veyra.calc.ui.screens.*
import com.veyra.calc.ui.theme.VeyraCalcTheme

enum class Screen(val title: String, val icon: ImageVector) {
    Calculator("Calculator", Icons.Default.Calculate),
    Percentage("Percent", Icons.Default.Percent),
    UnitConverter("Convert", Icons.Default.SwapHoriz),
    Formulas("Formulas", Icons.Default.MenuBook),
    History("History", Icons.Default.History)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var isDarkTheme by remember { mutableStateOf(true) }
            var currentScreen by remember { mutableStateOf(Screen.Calculator) }

            VeyraCalcTheme(darkTheme = isDarkTheme) {
                Scaffold(
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp
                        ) {
                            Screen.values().forEach { screen ->
                                NavigationBarItem(
                                    selected = currentScreen == screen,
                                    onClick = { currentScreen = screen },
                                    icon = { Icon(screen.icon, contentDescription = screen.title) },
                                    label = { Text(screen.title) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentScreen) {
                            Screen.Calculator -> CalculatorScreen()
                            Screen.Percentage -> PercentageScreen()
                            Screen.UnitConverter -> UnitConverterScreen()
                            Screen.Formulas -> FormulaLibraryScreen()
                            Screen.History -> HistoryScreen()
                        }
                    }
                }
            }
        }
    }
}
