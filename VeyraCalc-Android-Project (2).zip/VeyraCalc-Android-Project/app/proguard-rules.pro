# ProGuard rules
-keep class com.veyra.calc.engine.** { *; }

# Google Mobile Ads SDK rules
-keep public class com.google.android.gms.ads.** {
   public *;
}
-dontwarn com.google.android.gms.ads.**

